ssh -i "rsa_key_for_instance.pem" ubuntu@34.222.249.51
